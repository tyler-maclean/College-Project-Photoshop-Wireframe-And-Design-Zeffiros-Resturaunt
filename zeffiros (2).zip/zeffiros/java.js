$(document).ready(function() {
	
   "use strict";

$("#home-image > div:gt(0)").hide();

setInterval(function() {
  $('#home-image > div:first')
    .fadeOut(1000)
    .next()
    .fadeIn(1000)
    .end()
    .appendTo('#home-image');
}, 3000);});